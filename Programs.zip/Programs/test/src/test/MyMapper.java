package test;

 

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable> { //Generics define type of input and output
	public void map(LongWritable inkey, Text inval,Context context) throws IOException, InterruptedException
	{
		//33 abc pqr abc xyz -> inkey : 33 / inval : abc pqr abc xyz
		
		String line = inval.toString().toUpperCase(); //abc pqr abc xyz
		
		String[] lineparts = line.split(" ");
		
		for(String word : lineparts)
		{
//For particular Word Count
//			if(word.matches("NANDITA")){
			Text mapOutKey = new Text(word);
			IntWritable mapOutVal = new IntWritable(1);
			context.write(mapOutKey,mapOutVal); 
//			}
			
			
			
		}
	}

}
