package test;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer <Text,IntWritable,Text,IntWritable>{
	public void reduce(Text inkey,Iterable<IntWritable> invals,Context context) throws IOException, InterruptedException{
		//abc(1,1,1,1,1) : abc->inkey | (1,1,1,1,1)->invals
		int count=0;
		for(IntWritable singlevalue : invals)
		{
			//
			count++;
		}
		context.write(inkey,new IntWritable(count));
	}
}
