package test;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class MyPartitioner extends Partitioner<Text, IntWritable> {

	@Override
	public int getPartition(Text arg0, IntWritable arg1, int numreducer) {
		
		//return arg0.hashCode()%numreducer;
		if(arg0.toString().startsWith("A")) 
			return 0;
		else if(arg0.toString().startsWith("N"))
			return 1;
		else
			return 2;
	}

}
