package mapsidejoin;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MapSideReducer extends Reducer<Text, Text, Text, DoubleWritable> {
	public void reduce(Text inkey, Iterable<Text> invalues, Context context) throws IOException, InterruptedException{
		double sum=0;
		for(Text invalue : invalues){
			 double amount = Double.parseDouble(invalue.toString());
			 sum+=amount;
		}
		context.write(inkey, new DoubleWritable(sum));
	}
}
