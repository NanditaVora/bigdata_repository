package mapsidejoin;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapSideMapper extends Mapper<LongWritable, Text, Text, Text> {
	
	public TreeMap<Text,Text> Customers=new TreeMap<>();
	
	@Override
	protected void setup(org.apache.hadoop.mapreduce.Mapper<LongWritable,Text,Text,Text>.Context context) throws java.io.IOException ,InterruptedException {
		FileInputStream fis = new FileInputStream("/home/hduser/demos/custs-large.dat");
		 
		//Construct BufferedReader from InputStreamReader
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));
	 
		String line = null;
		while ((line= br.readLine()) != null) {
			 
			String[]parts = line.split(",");
			String uid = parts[0];
			String name = parts[1];
			Customers.put(new Text(uid), new Text(name));
		}
		
		br.close();	
	};
	
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String record = invalue.toString();
		String[] parts = record.split(",");
		
		String uid = parts[2];
		String amount = parts[3];
		
		Set<Text> uids = Customers.keySet();
		Iterator<Text> uiditr = uids.iterator();
		while(uiditr.hasNext()){
			Text userid = new Text(uiditr.next().toString());
			if(userid.toString().equals(uid)){
				context.write(Customers.get(userid), new Text(amount));
			}
		}
		
		
	}

}
