package task2;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class CountByAmountReducer extends Reducer<DoubleWritable, IntWritable, DoubleWritable, IntWritable> {
	public void reduce(DoubleWritable inkey,Iterable<IntWritable> invals,Context context) throws IOException, InterruptedException{
		 
		int count=0;
		for(IntWritable singlevalue : invals)
		{
			 
			count++;
		}
		context.write(inkey,new IntWritable(count));
	}

}
