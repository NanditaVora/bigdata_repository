package task2;

import java.io.IOException;

 
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CountByAmountMapper extends Mapper<LongWritable, Text, DoubleWritable, IntWritable> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String line = invalue.toString();
		String[] tokens = line.split(",");
		
		double amount = Double.parseDouble(tokens[3]);
		
		if(amount>160)
		{
			context.write(new DoubleWritable(amount),new IntWritable(1));
		}
	}
}
