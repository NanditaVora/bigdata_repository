package task3;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class SumCountReducer extends Reducer<Text, DoubleWritable, Text, Text> {
	public void reduce(Text inkey,Iterable<DoubleWritable> invals,Context context) throws IOException, InterruptedException{
		int count = 0;
		double sum = 0;
		for(DoubleWritable amt : invals)
		{
			sum = sum + amt.get();
			count++;
		}
		context.write(inkey, new Text("Sum = " + sum + " Count = " + count));
	}

}
