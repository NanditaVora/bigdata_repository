package reducedsidejoin;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TransactionMapper extends Mapper<LongWritable, Text,Text, Text> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String record = invalue.toString();
		String parts[] = record.split(",");
		String uid = parts[2];
		String Amt = "Amt:" + parts[3];		
		context.write(new Text(uid), new Text(Amt));
	}
}
