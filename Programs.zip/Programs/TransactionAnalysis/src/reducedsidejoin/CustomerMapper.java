package reducedsidejoin;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

public class CustomerMapper extends Mapper<LongWritable, Text, Text,Text> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String record = invalue.toString();
		String parts[] = record.split(",");
		String uid = parts[0];
		String name = "Name:" + parts[1];
		context.write(new Text(uid), new Text(name));
		
		
	
		
	}
}
