package reducedsidejoin;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TransactCustomerReducer extends Reducer<Text, Text, Text, DoubleWritable> {
	public void reduce(Text inkey, Iterable<Text> invalues, Context context) throws IOException, InterruptedException{
		double sum=0;
		Text name=null;
		for(Text invalue : invalues){
			String[] value = invalue.toString().split(":");
		//	if(invalue.toString().startsWith("Name")){
			if(value[0].equals("Name")){
				//name = new Text(invalue.toString().split(":")[1]);
				name = new Text(value[1]);
			}
			//else if(invalue.toString().startsWith("Amt")){
			else if(value[0].equals("Amt")){
				//sum += Double.parseDouble(invalue.toString().split(":")[1]);
				sum+=Double.parseDouble(value[1]);
			}
			else
			{
				name=new Text("Nandita");
				sum=100.0;
			}
		}
		context.write(name, new DoubleWritable(sum));
	}

}
