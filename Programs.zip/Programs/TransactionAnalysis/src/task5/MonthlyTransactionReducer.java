package task5;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MonthlyTransactionReducer extends Reducer<Text, Text, Text, NullWritable> {
	public void reduce(Text inkey,Iterable<Text> invalues,Context context) throws IOException, InterruptedException{
		
	for(Text invalue:invalues){
		context.write(invalue, null);
	}
	}

}


//Can there be Mapper Partitioner but no Reducer