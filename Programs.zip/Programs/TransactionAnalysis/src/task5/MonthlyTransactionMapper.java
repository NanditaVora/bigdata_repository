package task5;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MonthlyTransactionMapper extends Mapper<LongWritable, Text, IntWritable, Text> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String line = invalue.toString();
		String[] tokens = line.split(",");
		
		context.write(new IntWritable(Integer.parseInt(tokens[1].substring(0, 2))),invalue);
		
	}
}
