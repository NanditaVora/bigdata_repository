package task5;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class MonthlyTransactionPartitioner extends Partitioner<IntWritable, Text> {

	@Override
	public int getPartition(IntWritable arg0, Text arg1, int arg2) {
		 
		return arg0.get()%12;
	}

}
