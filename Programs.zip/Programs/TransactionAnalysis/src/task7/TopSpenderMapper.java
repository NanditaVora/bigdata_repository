package task7;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TopSpenderMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String line = invalue.toString();
		String[] tokens = line.split(",");
		
		context.write(new Text(tokens[2]), new DoubleWritable(Double.parseDouble(tokens[3])));
	}
}
