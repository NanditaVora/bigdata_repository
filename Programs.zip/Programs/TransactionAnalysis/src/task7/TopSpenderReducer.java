package task7;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TopSpenderReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
	TreeMap< DoubleWritable,Text> list = new TreeMap<>();
	//TreeMap<Text,DoubleWritable> list = new TreeMap<>();
	public void reduce(Text inkey, Iterable<DoubleWritable> invalues,Context context) throws IOException, InterruptedException{
		double sum = 0;
		for(DoubleWritable amt : invalues){
			
			sum = sum + amt.get();
		
		}
		//list.put(inkey,new DoubleWritable(sum));
		list.put(new DoubleWritable(sum),inkey);
		context.write(inkey, new DoubleWritable(sum));
	}
	public void cleanup(Context context) throws IOException, InterruptedException
	{
		//context.write(new Text("Nandita"), new DoubleWritable(100.0));
		
		Set keys = list.keySet();
		Collection values=list.values();
		Iterator valitr= values.iterator();
		Iterator itr = keys.iterator();
		int n=keys.size()-1;
		int count=0;
		while(count<n)
		{
			itr.next();
			valitr.next();
			count++;
		}
		//Text uid = new Text(itr.next().toString());
		DoubleWritable sum = new DoubleWritable(Double.parseDouble(itr.next().toString()));
		context.write(new Text("N"),sum);
	}
}
