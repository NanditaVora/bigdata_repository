package task4;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class MonthlySalesReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
	public void reduce(Text inkey,Iterable<DoubleWritable> invals,Context context) throws IOException, InterruptedException{
		int count = 0;
		double sum = 0;
		for(DoubleWritable amt : invals)
		{
			sum = sum + amt.get();
			 
		}
		context.write(inkey, new DoubleWritable(sum));
	}
}
