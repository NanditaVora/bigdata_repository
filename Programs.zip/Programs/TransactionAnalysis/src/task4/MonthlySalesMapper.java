package task4;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class MonthlySalesMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String line = invalue.toString();
		
		String tokens[] = line.split(",");
		
		String month = tokens[1].substring(0, 2);
		
		context.write(new Text(month), new DoubleWritable(Double.parseDouble(tokens[3])));
	}

}
