package task6;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class SortByAmtReducer extends Reducer<Text, Text, Text, NullWritable> {
	public void reduce(Text inkey, Iterable<Text> invalue,Context context) throws IOException, InterruptedException{
		for(Text val : invalue){
			context.write(val, null);
		}
	}

}
