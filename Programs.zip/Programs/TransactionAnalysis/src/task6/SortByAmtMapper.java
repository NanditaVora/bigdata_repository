package task6;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SortByAmtMapper extends Mapper<LongWritable,Text,Text, Text> {
	public void map(LongWritable inkey, Text invalue,Context context) throws IOException, InterruptedException{
		String line = invalue.toString();
		String[] tokens = line.split(",");
		context.write(new Text(tokens[3]), invalue);
		
	}

}
