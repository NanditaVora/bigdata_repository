package transactionsearch;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SearchMapper extends Mapper<LongWritable, Text, Text, NullWritable> {
	public void map(LongWritable inkey,Text invalue, Context context) throws IOException, InterruptedException{
		String line=invalue.toString();
		System.out.println(line);
		String records[] = line.split(",");
		 
			if(records[2].matches("4001364")){
				 
				context.write(invalue,null); 
			}
			
		 
		
	}

}
